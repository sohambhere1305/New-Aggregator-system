from django.db import models

class News(models.Model):
    title = models.CharField(max_length=255)
    url = models.URLField()
    image = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.title