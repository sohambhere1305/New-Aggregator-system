import requests
from django.shortcuts import render, redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

API_KEY = "6619aa9ca8cd13972ccf412a1d193696"
BASE_URL = "https://gnews.io/api/v4/top-headlines"

CATEGORIES = [
    "sports", "entertainment", "business", "technology", "science", "health",
    "world", "nation", "lifestyle"
]

# Redirect root ('/') to General News
def redirect_to_general(request):
    return redirect('fetch_news', category='general')

def fetch_news(request, category="general"):
    # Ensure default category is "general" for invalid or empty categories
    if category not in CATEGORIES:
        category = "general"

    # Fetch news articles from the API
    params = {
        "token": API_KEY,
        "lang": "en",
        "topic": category
    }

    # Search query handling
    query = request.GET.get('q')
    if query:
        params["q"] = query

    try:
        response = requests.get(BASE_URL, params=params)
        response.raise_for_status()
        data = response.json()
        articles = data.get("articles", [])
    except requests.RequestException as e:
        print(f"Error fetching news: {e}")
        articles = []

    # Ensure at least 24 articles by duplicating if needed (for 2 full pages)
    while len(articles) < 24:
        articles.extend(articles[:24 - len(articles)])

    # Pagination: Display 12 articles per page
    paginator = Paginator(articles, 12)
    page = request.GET.get('page')

    try:
        articles = paginator.page(page)
    except PageNotAnInteger:
        articles = paginator.page(1)  # Default to first page
    except EmptyPage:
        articles = paginator.page(paginator.num_pages)  # Last page if out of range

    return render(request, "news.html", {
        "news": articles,
        "categories": CATEGORIES,
        "active_category": category,
        "query": query
    })
