from django.urls import path
from . import views

urlpatterns = [
    path('', views.redirect_to_general, name='home'),  # Redirect to General News
    path('news/<str:category>/', views.fetch_news, name='fetch_news'),
]
